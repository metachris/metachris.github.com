int get_cpuinfo_revision(char *revision_hex);
